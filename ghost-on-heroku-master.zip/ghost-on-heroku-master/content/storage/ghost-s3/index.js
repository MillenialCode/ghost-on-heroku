'use strict';
module.exports = require('ghost-s3-storage-adapter');
